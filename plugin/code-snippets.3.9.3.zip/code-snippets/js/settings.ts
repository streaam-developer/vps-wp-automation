import { handleEditorPreviewUpdates, handleSettingsTabs, initVersionSwitch } from './services/settings'

handleSettingsTabs()
handleEditorPreviewUpdates()
initVersionSwitch()
