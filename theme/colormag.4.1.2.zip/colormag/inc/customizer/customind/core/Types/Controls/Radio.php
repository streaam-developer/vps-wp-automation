<?php
/**
 * Radio class.
 */
namespace Customind\Core\Types\Controls;

/**
 * Radio control class.
 */
class Radio extends AbstractControl {

	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-radio';
}
