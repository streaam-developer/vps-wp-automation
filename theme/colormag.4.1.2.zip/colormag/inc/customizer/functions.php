<?php
/** @return \Customind\Core\Customind */
function colormag_customind() {
	global $customind;
	return $customind;
}
