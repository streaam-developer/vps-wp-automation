<?php
/**
 * Portofolio starter content.
 *
 * @package ColorMag\Compatibility\Starter_Content
 */

return [
	'post_type'    => 'page',
	'post_title'   => _x( 'Sports', 'Theme starter content', 'colormag' ),
	'post_content' => '',
];
