<?php

dynamic_sidebar( 'colormag_header_sidebar' );
