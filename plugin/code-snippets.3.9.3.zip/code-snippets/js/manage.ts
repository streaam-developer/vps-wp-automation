import { handleShowCloudPreview, handleSnippetActivationSwitches, handleSnippetPriorityChanges } from './services/manage'

handleSnippetActivationSwitches()
handleSnippetPriorityChanges()
handleShowCloudPreview()
