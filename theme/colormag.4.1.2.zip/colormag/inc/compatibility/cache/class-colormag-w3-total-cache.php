<?php


class ColorMag_W3_Total_Cache {
	/**
	 * Cache plugin slug.
	 *
	 * @var string
	 */
	protected $plugin = 'w3-total-cache/w3-total-cache.php';


}
