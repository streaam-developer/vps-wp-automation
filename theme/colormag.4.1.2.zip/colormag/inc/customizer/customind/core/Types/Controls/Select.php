<?php
/**
 * Select control class.
 */
namespace Customind\Core\Types\Controls;

/**
 * Select control class.
 */
class Select extends AbstractControl {
	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-select';
}
