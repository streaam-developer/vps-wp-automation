<?php
/**
 * Heading class.
 */

namespace Customind\Core\Types\Controls;

/**
 * Heading class.
 */
class Heading extends AbstractControl {

	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-heading';
}
