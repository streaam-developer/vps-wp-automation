<?php
/**
 * Textarea control class.
 */
namespace Customind\Core\Types\Controls;

/**
 * Textarea control class.
 */
class Textarea extends AbstractControl {

	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-textarea';
}
