<?php

dynamic_sidebar( 'colormag_footer_sidebar_three_upper' );
