export { handleSettingsTabs } from './tabs'
export { handleEditorPreviewUpdates } from './editor-preview'
export { initVersionSwitch } from './version'
